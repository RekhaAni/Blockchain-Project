# blockchain/smart_contract.py

from .blockchain import Blockchain

class SmartContract:
    def __init__(self):
        self.blockchain = Blockchain()

    def create_land_record(self, survey_number, owner_name, location):
        # Add a new land record to the blockchain
        transaction = {
            'survey_number': survey_number,
            'owner_name': owner_name,
            'location': location
        }
        self.blockchain.new_transaction(transaction)

    def transfer_ownership(self, survey_number, new_owner):
        # Transfer ownership of a property
        transaction = {
            'survey_number': survey_number,
            'new_owner': new_owner
        }
        self.blockchain.new_transaction(transaction)
class LandRecord:
    def __init__(self, owner, survey_number, location):
        self.owner = owner
        self.survey_number = survey_number
        self.location = location

    def to_dict(self):
        return {
            "owner": self.owner,
            "survey_number": self.survey_number,
            "location": self.location
        }
from blockchain.blockchain import Blockchain


class SmartContract:
    def __init__(self):
        self.blockchain = Blockchain()

    def create_land_record(self, survey_number, owner_name, location):
        """
        Create a new land record and add it to the blockchain
        :param survey_number: Unique identifier for the land
        :param owner_name: Name of the owner
        :param location: Location of the land
        """
        transaction_details = {
            "survey_number": survey_number,
            "owner_name": owner_name,
            "location": location,
        }
        self.blockchain.new_transaction(sender="System", recipient=owner_name, details=transaction_details)

    def transfer_ownership(self, survey_number, new_owner):
        """
        Transfer ownership of a property and add the transaction to the blockchain
        :param survey_number: Unique identifier for the land
        :param new_owner: Name of the new owner
        """
        transaction_details = {
            "survey_number": survey_number,
            "new_owner": new_owner,
        }
        self.blockchain.new_transaction(sender="Current Owner", recipient=new_owner, details=transaction_details)

    def validate_integrity(self):
        """
        Validate the integrity of the blockchain
        :return: True if valid, False otherwise
        """
        return self.blockchain.validate_chain()
import hashlib

# Simulated database for users
users_db = {}

def register_user(username, password, role):
    if username in users_db:
        return "Username already exists!"
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    users_db[username] = {"password": hashed_password, "role": role}
    return f"User '{username}' registered successfully as {role}."

def login(username, password):
    hashed_password = hashlib.sha256(password.encode()).hexdigest()
    if username in users_db and users_db[username]["password"] == hashed_password:
        return users_db[username]["role"]
    return None